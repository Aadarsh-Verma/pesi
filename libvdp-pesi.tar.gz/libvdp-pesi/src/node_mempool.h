extern struct mempool *mempool;
size_t node_size();
